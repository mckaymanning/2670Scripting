﻿public class statics
{

    public static float distance = 4;
    public static float nextPosition = 4;

}
