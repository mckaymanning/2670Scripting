﻿public class staticVars {

    public static float distance = 22;
    public static float nextSectionPosition = 22;
    public static float startPosition = 22;
}